
#include "SRC/COMMON.H"

LRESULT CALLBACK WindowProc(HWND, UINT, WPARAM, LPARAM);
void EnableOpenGL(HWND hwnd, HDC*, HGLRC*);
void DisableOpenGL(HWND, HDC, HGLRC);

void deleteModels(animated_model_t * model)
{
    for (unsigned int i=0; i<model->nbModels; i++) {
        if (model->model[i].pltbl) free(model->model[i].pltbl);
        if (model->model[i].pntbl) free(model->model[i].pntbl);
    }

    for (unsigned int i=0; i<model->nbFrames; i++) {
        if (model->keyFrames)
        {
            //if (model->keyFrames[i].cNorm) free(model->keyFrames[i].cNorm);
            if (model->keyFrames[i].cVert) free(model->keyFrames[i].cVert);
        }
    }


    for (unsigned int i=0; i<model->nbTextures; i++) {
        if (model->texture[i].pixel) free(model->texture[i].pixel);
    }


    if (model->texture)  free(model->texture);
    if (model->model)    free(model->model);
    if (model->nbFrames) free(model->keyFrames);
    free(model);
}

/***************************************
* UGLY UGLY GLOBALS... TO BE REMOVED SOMEDAY...
***********************************/
unsigned int texId[1280];
string PdataName[256];
int DisplayTEST=0;
int ZT_FRAMERATE=1;
player_t PLAYER[4];
int enableInterpolation=1;

uv_t   texture_coord[maxPolygons*4];
uint32_t tot_tex_coord = 0;
uint32_t useUV = 0;
uint32_t specialOption = 0;
uint8_t clearColor[4] ={128, 128, 128, 255};
texture_t skin;
BOOL bQuit = FALSE;

extern void                     initOpenGL();
extern animated_model_t *       loading(string line);
extern void                     setTextures(animated_model_t * model);
extern int                      render(animated_model_t * aModel);
extern void                     calcLight(animated_model_t*);

WNDCLASSEX wcex;
HWND hwnd;
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
    extern void writeNormLUT(void);
    writeNormLUT();



    HDC hDC;
    HGLRC hRC;
    MSG msg;


    /* register window class */
    wcex.cbSize = sizeof(WNDCLASSEX);
    wcex.style = CS_OWNDC;
    wcex.lpfnWndProc = WindowProc;
    wcex.cbClsExtra = 0;
    wcex.cbWndExtra = 0;
    wcex.hInstance = hInstance;
    wcex.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
    wcex.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    wcex.lpszMenuName = NULL;
    wcex.lpszClassName = "ZTP_CONVERTER";
    wcex.hIconSm = LoadIcon(NULL, IDI_APPLICATION);;


    if (!RegisterClassEx(&wcex))
        return 0;


  // char** argv = &lpCmdLine;
char** argv = &lpCmdLine;
    animated_model_t * model = loading(argv[0]);

    if (!bQuit){
            /* create main window */
        hwnd = CreateWindowEx(0, "ZTP_CONVERTER", 0, WS_CLIPSIBLINGS | WS_CLIPCHILDREN | WS_POPUP,
                         /** "ZTP_CONVERTER",
                          "ZTP CONVERTER", WS_OVERLAPPEDWINDOW,*/
                          64, 64,
                          1024, 640, NULL, NULL, hInstance, NULL);
        ShowWindow(hwnd, nCmdShow);
        EnableOpenGL(hwnd, &hDC, &hRC);
    }


    initOpenGL();

    cout << "Setting textures...\n";
    setTextures(model);

    cout << "Preview...\n";
    extern void resetPlayer(player_t *);
    for (int pl=0; pl<4; pl++) {resetPlayer(&PLAYER[pl]);}
            PLAYER[0].ANIMCTRL.fps=2;
            PLAYER[0].ANIMCTRL.startFrm= 0;
            PLAYER[0].ANIMCTRL.endFrm= model->nbFrames; //The end frame is EXCLUDED. So 1 to 3 is really just 2 frames

/**
    for (uint32_t i=0; i<tot_tex_coord; i++) {
        cout << (int)(texture_coord[i].U*65536) << ", " << (int)(texture_coord[i].V*65536) << "\n";
    }*/
    /* program main loop */
    while (!bQuit)
    {
        /* check for messages */
        if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
        {
            /* handle or dispatch messages */
            if (msg.message == WM_QUIT)
            {
                bQuit = TRUE;
            }
            else
            {
                TranslateMessage(&msg);
                DispatchMessage(&msg);
            }
        }
        glClearColor(0.4f, 0.4f, 0.5f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);
        glMatrixMode(GL_MODELVIEW);
        glDisable(GL_CULL_FACE);
        glColor4f(1.0f,1.0f,1.0f,1.0f);

        glPushMatrix();
        glMatrixMode(GL_MODELVIEW);
        gluLookAt(0.0, 0.0, -0.1, 0.0, 0.0, 0.0, 0.0, -1.0, 0.0);

        extern int myControls(player_t*, animated_model_t*);
        bQuit = myControls(&PLAYER[0], model);
        PLAYER[0].POSITION[X] = PLAYER[0].NEXT_POSITION[X];
        PLAYER[0].POSITION[Y] = PLAYER[0].NEXT_POSITION[Y];
        PLAYER[0].POSITION[Z] = PLAYER[0].NEXT_POSITION[Z];


        if (DisplayTEST==0) glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
         else glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

        render(model);
        glPopMatrix();

        renderText(model);



        SwapBuffers(hDC);
        Sleep (ZT_FRAMERATE);
        glClear(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);
    }

#if 1
    extern string fileOutName;// = "OUT/" + fileIn;
    const char * path = "OUT/";
    CreateDirectory(path, NULL);
    cout << "NOW CREATING BINARY FILE " << fileOutName << ".ZTP\n";
    string binaryFileName = "OUT\\" + fileOutName + ".ZTP";  //Z-Treme character

    ofstream binFile(binaryFileName.c_str(), ios::out | ios::binary);
    if (!binFile.is_open()) {cout << "\nERROR WHILE WRITING BINARY FILE!\n";}
    else {
        extern write_model_binary(ofstream*file, animated_model_t*aModel);
        extern bool write_MOD_HEADER(string filename, animated_model_t * aModel);

        write_model_binary(&binFile, model);
        cout << "Writing debug text file...\n";

        write_MOD_HEADER("OUT.TXT", model);
        binFile.close();
        extern int writeShadows(string, animated_model_t*);
        writeShadows("SHADOWS.TXT", model);
    }
#endif // 1

    /* shutdown OpenGL */
    DisableOpenGL(hwnd, hDC, hRC);

    /* destroy the window explicitly */
    DestroyWindow(hwnd);

    // Delete the arrays here
    deleteModels(model);
return 0;
    //return msg.wParam;
}



LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg)
    {
        case WM_CLOSE:
            PostQuitMessage(0);
        break;

        case WM_DESTROY:
            return 0;

        case WM_KEYDOWN:
        {
            switch (wParam)
            {
                case VK_ESCAPE:
                    PostQuitMessage(0);
                break;
            }
        }
        break;

        default:
            return DefWindowProc(hwnd, uMsg, wParam, lParam);
    }

    return 0;
}

void EnableOpenGL(HWND hwnd, HDC* hDC, HGLRC* hRC)
{
    PIXELFORMATDESCRIPTOR pfd;

    int iFormat;

    /* get the device context (DC) */
    *hDC = GetDC(hwnd);

    /* set the pixel format for the DC */
    ZeroMemory(&pfd, sizeof(pfd));

    pfd.nSize = sizeof(pfd);
    pfd.nVersion = 1;
    pfd.dwFlags = PFD_DRAW_TO_WINDOW |
                  PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
    pfd.iPixelType = PFD_TYPE_RGBA;
    pfd.cColorBits = 24;
    pfd.cDepthBits = 24;
    pfd.iLayerType = PFD_MAIN_PLANE;

    iFormat = ChoosePixelFormat(*hDC, &pfd);

    SetPixelFormat(*hDC, iFormat, &pfd);

    /* create and enable the render context (RC) */
    *hRC = wglCreateContext(*hDC);

    wglMakeCurrent(*hDC, *hRC);
}
void DisableOpenGL (HWND hwnd, HDC hDC, HGLRC hRC)
{
    wglMakeCurrent(NULL, NULL);
    wglDeleteContext(hRC);
    ReleaseDC(hwnd, hDC);
}

