#include "../COMMON.H"

extern player_t PLAYER[];
extern int ZT_FRAMERATE;


int testAnim = 0;

float SaturnUV[8*4] =
{
    0, 0,
    1, 0,
    1, 1,
    0, 1,

    1, 0,
    0, 0,
    0, 1,
    1, 1,

    0, 1,
    1, 1,
    1, 0,
    0, 0,

    1, 1,
    0, 1,
    0, 0,
    1, 0,
};


GLubyte meshEffectArray[]={
    15, 15, 15, 15, 240, 240, 240, 240,
    15, 15, 15, 15, 240, 240, 240, 240,
    15, 15, 15, 15, 240, 240, 240, 240,
    15, 15, 15, 15, 240, 240, 240, 240,
    15, 15, 15, 15, 240, 240, 240, 240,
    15, 15, 15, 15, 240, 240, 240, 240,
    15, 15, 15, 15, 240, 240, 240, 240,
    15, 15, 15, 15, 240, 240, 240, 240,
    15, 15, 15, 15, 240, 240, 240, 240,
    15, 15, 15, 15, 240, 240, 240, 240,
    15, 15, 15, 15, 240, 240, 240, 240,
    15, 15, 15, 15, 240, 240, 240, 240,
    15, 15, 15, 15, 240, 240, 240, 240,
    15, 15, 15, 15, 240, 240, 240, 240,
    15, 15, 15, 15, 240, 240, 240, 240,
    15, 15, 15, 15, 240, 240, 240, 240,
//    85, 85, 85, 85, 170, 170, 170, 170,

};

//Selection ID
int activeModel = 0;
int activeFace = -1;
int playAnimation = 1;
int activeShading = 1;
void ztUpdateAnimation(animationControl_t * animCtrl, animated_model_t * currentModel)
{
    if (currentModel->nbFrames==0)return;
    if (!playAnimation) return;
    //XPDATA * currentPDATA = currentModel->pol[0];
    //model_t * currentPDATA = currentModel->model[0];

    /**Sets the animation data**/
    animCtrl->currentFrm+=ZT_FRAMERATE;
    uint32_t FPS = animCtrl->fps;
    float percent = 1.0f/(float)(1<<FPS);
    if (animCtrl->currentFrm>=animCtrl->endFrm<<FPS)
        animCtrl->currentFrm-=(animCtrl->endFrm-animCtrl->startFrm)<<FPS;

    /**Safety measure**/
    if (animCtrl->currentFrm < animCtrl->startFrm<<FPS || animCtrl->currentFrm >= animCtrl->endFrm<<FPS)
        animCtrl->currentFrm=animCtrl->startFrm<<FPS;

    animCtrl->currentKeyFrm=animCtrl->currentFrm>>FPS;  //should be >>currentModel->AnimInterpolation; but I forgot to output 60 fps animations... No time to fix it...

    uint16_t nextKeyFrm=animCtrl->currentKeyFrm+1;
    if (nextKeyFrm>=animCtrl->endFrm)
        nextKeyFrm=animCtrl->startFrm;


    vertex_t * curKeyFrame = (vertex_t*)currentModel->keyFrames[animCtrl->currentKeyFrm].cVert;
    vertex_t * nextKeyFrame = (vertex_t*)currentModel->keyFrames[nextKeyFrm].cVert;

    uint16_t interpFctr = animCtrl->currentFrm-(animCtrl->currentKeyFrm<<FPS);

    /**Uncompress the vertices and apply linear interpolation**/

    /*vertex_t *dst=currentPDATA->pntbl[0];
    vertex_t *src=curKeyFrame[0];
    vertex_t *nxt=nextKeyFrame[0];*/
    /*for (i = 0; i < currentPDATA->nbPoint*sizeof(vertex_t); i+= sizeof(vertex_t)) {
		*dst++=(*src+(((*nxt-*src)*interpFctr)>>FPS));  //Here is a "mistake" : Using <<8 would be faster since the SH2 supports a shift left 8 instruction, but I didn't know it when I made this animation tool. To be changed to 8 instead
		*src++; *nxt++;
    }*/


    extern int enableInterpolation;
    if (!enableInterpolation) {interpFctr=0;}
    unsigned int j=0;
    for (unsigned int i=0; i<currentModel->nbModels; i++)
        {
            model_t * currentPDATA = &currentModel->model[i];
            for (unsigned int ii=0; ii<currentModel->model[i].nbPoint; ii++)
            {
                vertex_t *dst=(vertex_t*)&currentPDATA->pntbl[ii];
                vertex_t *src=(vertex_t*)&curKeyFrame[j];
                vertex_t *nxt=(vertex_t*)&nextKeyFrame[j];

                for (uint32_t v=0; v<3; v++) {
                   dst->point[v]=(src->point[v]) + (((nxt->point[v]-src->point[v])*interpFctr)*percent);
                }


                /*(aModel->keyFrames[curFrame].cVert[j].point[X]) + (percentage2 * aModel->keyFrames[nextFrame].cVert[j].point[X]);

                aModel->model[i].pntbl[ii].point[Y]=
                (percentage * aModel->keyFrames[curFrame].cVert[j].point[Y]) + (percentage2 * aModel->keyFrames[nextFrame].cVert[j].point[Y]);

                aModel->model[i].pntbl[ii].point[Z]=
                (percentage * aModel->keyFrames[curFrame].cVert[j].point[Z]) + (percentage2 * aModel->keyFrames[nextFrame].cVert[j].point[Z]);*/
                j++;
            }
        }

    /*  *dst=currentPDATA->pltbl[0].norm[0];
    Uint8 *src2=currentModel->animation[animCtrl->currentKeyFrm]->cNorm;
    for (i = 0; i < currentPDATA->nbPolygon; i++)    {
        *dst++=anorms[*src2][X];
        *dst++=anorms[*src2][Y];
        *dst=anorms[*src2++][Z];
        dst=dst+3 ; //++; *dst++;
    }*/
}

int render(animated_model_t * aModel)
{

            glPushMatrix();

            glRotatef(PLAYER[0].ROTATION[X], 1.0f, 0.0f, 0.0f);
            glRotatef(PLAYER[0].ROTATION[Y], 0.0f, 1.0f, 0.0f);
            glTranslatef(-PLAYER[0].POSITION[X], -PLAYER[0].POSITION[Y], -PLAYER[0].POSITION[Z]);
            glScalef(aModel->scale[X],aModel->scale[Y], aModel->scale[Z]);

            extern int DisplayTEST;
            if (!(DisplayTEST&1))glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
            else  glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

        /*    if (DisplayTEST>1)
            else useUV=1;*/
//useUV=0;
uint32_t newUseUV=useUV;
#if 1
newUseUV=0;
#endif


            glEnable(GL_BLEND);
            glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);
           // glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, 0x0105);
            //glBlendFunc(GL_FUNC_ADD, GL_ONE_MINUS_SRC_ALPHA);

            if (aModel->nbFrames>0)
            {

                ztUpdateAnimation(&PLAYER[0].ANIMCTRL, aModel);
                //testAnim+=ZT_FRAMERATE;
                //if (testAnim >= aModel->nbFrames*playSpeed) testAnim=0;
            }

            const float cOffset = 0.5;
            extern unsigned int texId[];
            for (unsigned int m=0; m<aModel->nbModels; m++)
            {
                model_t * curModel = &aModel->model[m];
                vertex_t * curVert;
                for (unsigned int i=0; i<curModel->nbPolygon; i++)
                {

                    polygon_t * pol = &curModel->pltbl[i];
                    glBindTexture(GL_TEXTURE_2D, texId[pol->texture]);
                    if (aModel->texture[pol->texture].attributes & TEX_NO_GOURAUD) glColor4f(1,1,1,1);
                    if (pol->SGL_ATTR.flag & Dual_Plane) glDisable(GL_CULL_FACE);
                    else glEnable(GL_CULL_FACE);

                   // float transValue = 1.0f;
                    int dir = (pol->SGL_ATTR.dir>>4)&3;
                    if (pol->SGL_ATTR.atrb &MESHon){
                        glEnable(GL_POLYGON_STIPPLE);
                        glPolygonStipple(meshEffectArray);
                    } else {
                        glDisable(GL_POLYGON_STIPPLE);
                    }

                    glBegin(GL_QUADS);
                    {

                        for (int32_t ii=3; ii>=0; --ii) {
                            if (newUseUV)
                                glTexCoord2f(pol->vertUV[ii].U, pol->vertUV[ii].V);
                            else
                                glTexCoord2f(SaturnUV[ii*2+(dir*8)], (SaturnUV[(ii*2) + 1 + (dir*8)]));
                            curVert = &curModel->pntbl[pol->vertIdx[ii]];

                            if (activeFace==i && activeModel==m)
                                glColor4f(0.75,0.25,0.25,0.66);
                            else{
                                if (activeShading && ((!(aModel->texture[pol->texture].attributes & TEX_NO_GOURAUD)) && (pol->SGL_ATTR.atrb&CL_Gouraud))) {
                                    glColor4f(curVert->color[0]*0.5+cOffset,curVert->color[1]*0.5+cOffset,curVert->color[2]*0.5+cOffset,1.0f);
                                } else {
                                    glColor4f(1,1,1,1.0f);
                                }

                            }
                            glVertex3f(curVert->point[X], curVert->point[Y], curVert->point[Z]);
                        }

                    }
                    glEnd();
                }
            }

            glPopMatrix();

            return 1;
}


const float offsetU = 16.0/256.0;
const float offsetV = 16.0/256.0;

float textUV[] = {
   /* 0, 1,
    1, 1,
    1, 0,*/


    0,       offsetV,
    offsetU, offsetV,
    offsetU, 0,
    0,       0,
};

const float textVertValue = 1/28.0f;
float textVert[] = {
    0, 0,
    textVertValue, 0,
    textVertValue, textVertValue,
    0, textVertValue,
};

float drawText(char * ptr, float x, float y){
    unsigned int t;
    float posX = -1 + textVertValue + x*textVertValue;
    float posY = 1 - textVertValue - y*textVertValue;
    while (*ptr)
    {
        t = (unsigned int)*ptr;
        if (t=='\n' || t=='\r\n') {
            ptr++;
            posX = -1 + textVertValue + x*textVertValue;
            posY -= textVertValue;
            continue;
        }
        glBegin(GL_QUADS);
        {
            for (int32_t ii=3; ii>=0; --ii) {
                glTexCoord2f(textUV[ii*2] + (t&15)*offsetU, textUV[ii*2+1] + t/16*offsetV);
                glVertex2f(textVert[ii*2]+posX, textVert[ii*2+1]+posY);
            }
        }
        glEnd();
        posX += textVertValue;
        ptr++;

        if (posX>=1) {
            posX = -1 + textVertValue + x*textVertValue;
            posY -= textVertValue;
        }
    }
    return posY;
}

string sortInfoArray[]={
    "SORT_BFR" ,			/* ���O�ɕ\�������|���S���̈ʒu���g�� */
	"SORT_MIN" ,			/* �S�_�̓�?A��Ԏ�O�̓_���g�� */
	"SORT_MAX" ,			/* �S�_�̓���ԉ����_���g�� */
	"SORT_CEN"
};

string cmdCtrlInfoArray[]={
    "FUNC_Normal",              //0
    "FUNC_Scaled_sprite",       //1
    "FUNC_Distorted_sprite",    //2
    "INVALID...",               //3
    "FUNC_Polygon",             //4
    "FUNC_PolyLine",	        //5
    "FUNC_Line",        		//6
    "FUNC_SystemClip",      	//9
    "FUNC_UserClip", 	        //8
    "FUNC_BasePosition",    	//10
    "FUNC_End",
    "*",
    "*",
    "*",
    "*",
    "*",
    "NO_FLIP",
    "H_FLIP",
    "V_FLIP",
    "HV_FLIP",
};

string cmdtSpecialOptions[]={
    "",
    "UseTexture", //1
    "UseLight\n", //2
    "UseDepthShading\n",//3
    "UsePalette\n", //4
    "UseNearClip\n", //5
    "UseRealTimeGouraud\n", //6
};

string flagInfo[] = {
    "Backface culling ON",
    "Backface culling OFF",
};





void renderText(animated_model_t * model){
    extern unsigned int asciiTextureId;
    glColor4f(1,1,1,0.4);
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    gluLookAt(0, 0, 0, 0, 0, -1, 0, 1, 0);

    glBindTexture(GL_TEXTURE_2D, asciiTextureId);
    glDisable(GL_CULL_FACE);
    glDisable(GL_POLYGON_STIPPLE);
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);




    /**
            sprintf(s, "%06d", i+1);
        string postVal(s);
        string animName = inFolder + fileIn + "_" + postVal + ".obj";
    **/
    drawText( "ZTP MODEL CONVERTER 0.5", 16, 0);
    string nbModel = "ACTIVE MODEL : " +std::to_string(activeModel);
    string nbFace = "ACTIVE FACE : " +std::to_string(activeFace);
    drawText( &nbModel[0], 0, 1); //, 4);
    drawText( &nbFace  [0], 0, 2); //, 4);
    drawText("RIGHT CLICK TO LOOK, LEFT CLICK TO SELECT POLYGON", 0, 3);

    const int infoPosY = 47;
    const int polInfoPos[2] = {0, 35};
    int yPos=polInfoPos[1];
    if (activeFace!=-1){
    polygon_t * pol = &model->model[activeModel].pltbl[activeFace];
    string textureIndex = "Texture ID : " + std::to_string(pol->SGL_ATTR.texno);
    drawText(&textureIndex[0], 0, 4);

        drawText("POLYGON INFORMATION", polInfoPos[0], polInfoPos[1] );
        string polCTRL = "Ctrl : " + /*std::to_string(pol->SGL_ATTR.dir & (3 << 4))*/
            cmdCtrlInfoArray[((pol->SGL_ATTR.dir& (3<<4))>>4)+16] + " " +
            cmdCtrlInfoArray[pol->SGL_ATTR.dir&7] + ", Code " + std::to_string(pol->SGL_ATTR.dir);
        drawText(&polCTRL[0], polInfoPos[0], polInfoPos[1]+1 );

        string polPMOD = "Pmod : " + std::to_string(pol->SGL_ATTR.atrb) + ", Gouraud shading : "+ ((pol->SGL_ATTR.atrb&CL_Gouraud)?"YES":"NO");
        drawText(&polPMOD[0], polInfoPos[0], polInfoPos[1]+3 );

        string polFLAG = "Flag : " + flagInfo[pol->SGL_ATTR.flag];
        drawText(&polFLAG[0], polInfoPos[0], polInfoPos[1]+5 );

        /**string polColor = "Color : " + std::to_string(pol->SGL_ATTR.colno);
        drawText(&polColor[0], polInfoPos[0], polInfoPos[1]+4 );*/

        /**
            "UseTexture",
    "UseLight\n",
    "UseDepthShading\n",
    "UsePalette\n",
    "UseNearClip\n",
    "UseRealTimeGouraud\n",
        **/
        int opt = (pol->SGL_ATTR.sorting)&(0xFC);
        string polSort = "Options : " + ((opt&UseLight)?cmdtSpecialOptions[2]:cmdtSpecialOptions[0]) + ((opt&UseGouraud)?cmdtSpecialOptions[6]:cmdtSpecialOptions[0]) +
        ((opt&UsePalette)?cmdtSpecialOptions[4]:cmdtSpecialOptions[0]) +
        ((opt&UseDepth)?cmdtSpecialOptions[3]:cmdtSpecialOptions[0]) +
        ((opt&UseNearClip)?cmdtSpecialOptions[5]:cmdtSpecialOptions[0]) + "\n" +
        sortInfoArray[pol->SGL_ATTR.sorting&3];
        drawText(&polSort[0], polInfoPos[0], polInfoPos[1]+7 );

        drawText("R=ROTATE POLYGON\nM=TOGGLE MESH TRANSPARENCY, H=TOGGLE GOURAUD\nF=FLIP TEXTURE READ DIRECTION\nC=TOGGLE BACKFACE CULLING\nN=CHANGE SORTING RULE", 0, infoPosY+4);
    }
        drawText("P=PLAY/PAUSE ANIMATION\nI=TOGGLE INTERPOLATION (preview only)\nL=TOGGLE LIGHT (preview only)", 0, infoPosY);



    glPopMatrix();

}
