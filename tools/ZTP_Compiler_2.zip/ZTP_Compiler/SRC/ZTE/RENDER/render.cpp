#include "../../COMMON.H"

#define BACKFACE_CULLING_OFF (0x4000)
#define ZSORT_BFR (0)
#define ZSORT_MIN (0x1000)
#define ZSORT_MAX (0x2000)
#define ZSORT_CEN (0x3000)

#define VDP1_MAX (1023)
#define VDP1_MIN (-1024)

#define DRAW_DISTANCE (8192<<16)
#define PRECLIPPING_DISABLE (1<<11)
extern int currentMatrix;

typedef enum
{
	CLIP_LEFT = 1<<0,
	CLIP_RIGHT = 1<<1,
	CLIP_TOP = 1<<2,
	CLIP_BOTTOM = 1<<3,
	CLIP_FAR = 1<<4,
	CLIP_NEAR = 1<<5,
} CLIP_PLANE;

typedef struct{
    float           pnt[3];
    float           color;
    unsigned int    clipFlag;
    float           inverseZ;
} vertex2D_t;

/**INCOMPLETE**/
void ztDrawModel(model_t * model)
{

    float ScreenDist = 188.0;
    float ScreenDistClip = 188.0 / 32.0;

    vertex2D_t vBuf[model->nbPoint];
    vertex2D_t * v = &vBuf[0];
    vertex_t * pArray=model->pntbl ;
    float * m = &mtx[currentMatrix][0];
    float * p;

    for (unsigned int i=0; i<model->nbPoint; i++)
    {
        p=&pArray->point[X];

        v->pnt[Z] = m[8] * p[X] + m[9] * p[Y] + m[10] * p[Z] + m[11];

        if (v->pnt[Z] > ScreenDistClip ) v->clipFlag = 0;
        else
            {v->pnt[Z] = ScreenDistClip; v->clipFlag = CLIP_NEAR;}

        v->inverseZ = ScreenDist/v->pnt[Z];

        v->pnt[X] = ((m[0]*p[X] + m[1]*p[Y] + m[2]*p[Z] + m[3])*v->inverseZ) * (1.0/704.0);
        v->pnt[Y] = ((m[4]*p[X] + m[5]*p[Y] + m[6]*p[Z] + m[7])*v->inverseZ) * (1.0/448.0);

        v->color=pArray->color[0]+0.3;
        pArray++;
        v++;
    }
}

