#include "../../COMMON.H"

#if 0
int zbuffer[2048];
SPRITE_T spritebuf[2048];
const void* Zbuffer = (void*) (zbuffer);
const SPRITE_T* SpriteBuf = (SPRITE_T*) (spritebuf);
#endif
