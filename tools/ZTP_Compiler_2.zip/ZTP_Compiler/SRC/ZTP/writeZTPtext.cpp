#include "../COMMON.H"


#define test_convert(x) (x)//(x/65536)

#if 0
{
                            extern float SaturnUV[];
                            model_t * curModel = &aModel->model[m];
                            vertex_t * curVert;
                            file << "o " << pcx.name << "." << yVal++ << "\n";
                            for (unsigned int i=0; i<curModel->nbPoint; i++){
                                file << "v ";
                                file << curModel->pntbl[i].point[0]<< " ";
                                file << curModel->pntbl[i].point[1] << " ";
                                file << curModel->pntbl[i].point[2] << " ";
                                file << "\n";
                            }

                            for (unsigned int i=0; i<curModel->nbPolygon; i++){
                                int dir = (curModel->pltbl[i].SGL_ATTR.dir>>4)&3;
                                for (int ii=3; ii>=0; ii--){
                                    file << "vt " << SaturnUV[ii*2+(dir*8)] << " " << (SaturnUV[(ii*2) + 1 + (dir*8)]) << "\n";
                                }
                            }
                            int byteCode=0;
                            for (unsigned int i=0; i<curModel->nbPolygon; i++)
                            {
                                int j=polArray[i];
                                //if (aModel->texture[curModel->pltbl[j].texture].colorDepth==COL_16) {continue;} //temp

                                float transValue = 1.0f;
                                int dir = (curModel->pltbl[j].SGL_ATTR.dir>>4)&3;
                                //if (curModel->pltbl[i].atrb&MESHon) transValue=0.5f;


                                    file << "usemtl " << aModel->texture[curModel->pltbl[j].texture].name << "\n";
                                    file << "f ";

                                    for (int32_t ii=3; ii>=0; --ii) {
                                        file << curModel->pltbl[i].vertIdx[ii] + offsetV << "/" << ii+offsetVt /*(SaturnUV[ii*2+(dir*8)], (SaturnUV[(ii*2) + 1 + (dir*8)]))*/ << "/1 ";
                                    }
                                    file << "\n";


                            }
                            offsetV+=curModel->nbPoint;
                            offsetVt+=curModel->nbPolygon*4;
                        }

#endif // 0
extern string PdataName[];

bool write_MOD_HEADER(string filename, animated_model_t * aModel)
{
    ofstream file(filename, ios::out);
    if (!file.is_open()) {cout << "ERROR...\n"; return false;}

    file << "#ifndef LUTaddr\n";
    file << "#define     LUTaddr             (0x25C7A960)\n";
    file << "#define     returnLUTaddr(n)    (LUTaddr + (0x20 * n))\n";
    file << "#define     LUTidx(n)           (Uint16)(62764 + (4 * n))\n";
    file << "#define     CRAM_Base           (0x25f00200)\n";
    file << "#define     returnCRAMaddr(n)   (CRAM_Base + (0x20 * n))\n";
    file << "#define     LUTcramIdx(n)       ((256 + (16 * n)))\n";
    file << "#endif\n\n";

    for (unsigned int mesh=0; mesh < aModel->nbModels; mesh++)
    {
        model_t * m = &aModel->model[mesh];
        if (m->nbPolygon > 0)
        {
            file << "//MESH NO." << mesh << " : " << PdataName[mesh] << "\n";

            file << "POINT point_" << mesh << "[] = {\n";
            for (unsigned int i=0; i<m->nbPoint; i++)
            {
                file << "       POStoFIXED(" << (test_convert(m->pntbl[i].point[X])) << ", "
                << (test_convert(m->pntbl[i].point[Y])) << ", "
                << (test_convert(m->pntbl[i].point[Z])) << "),\n";
            }
            file << "};\n\n";

            file << "POLYGON polygon_" << mesh << "[] = {\n";
            for (unsigned int i=0; i<m->nbPolygon; i++)
            {
                file << "       NORMAL(";
                for (unsigned int j=0; j<3; j++)
                {file << (m->pltbl[i].normal[j]); if (j<2) file << ", ";}
                file << "), VERTICES(";
                for (unsigned int j=0; j<4; j++)
                {file << m->pltbl[i].vertIdx[j]; if (j<3) file << ", ";}
                file << "),\n";
            }
            file << "};\n\n";
#if 0
            file->write((char*)&aModel->texture[aModel->model[i].pltbl[ii].texture].SGL_ATTR.flag, sizeof(uint8_t));
            file->write((char*)&aModel->texture[aModel->model[i].pltbl[ii].texture].SGL_ATTR.sorting, sizeof(uint8_t));
            writeUint16(file, aModel->texture[aModel->model[i].pltbl[ii].texture].SGL_ATTR.texno);
            writeUint16(file, aModel->texture[aModel->model[i].pltbl[ii].texture].SGL_ATTR.atrb);
            writeUint16(file, aModel->texture[aModel->model[i].pltbl[ii].texture].SGL_ATTR.colno);
            writeUint16(file, aModel->texture[aModel->model[i].pltbl[ii].texture].SGL_ATTR.gstb);
            writeUint16(file, aModel->texture[aModel->model[i].pltbl[ii].texture].SGL_ATTR.dir);
#endif // 0
            file << "ATTR attribute_" << mesh << "[] = {\n";
            for (unsigned int i=0; i<m->nbPolygon; i++)
            {
                file << "       ATTRIBUTE(";
                file << "Single_Plane, SORT_CEN, ";
                file << m->pltbl[i].texture << ", LUTidx(" << m->pltbl[i].texture << "),";
                file << " No_Gouraud,Window_In|MESHoff|HSSon|ECdis|SPdis|CL_Gouraud|CL16Look,sprNoflip, UseNearClip),\n";
            }
            file << "};\n\n";

            file << "VECTOR normal_" << mesh << "[] = {\n";
            for (unsigned int i=0; i<m->nbPoint; i++)
            {
                file << "       POStoFIXED(" << (test_convert(m->pntbl[i].normal[X]))
                << ", " << (test_convert(m->pntbl[i].normal[Y])) << ", "
                << (test_convert(m->pntbl[i].normal[Z])) << "),\n";
            }
            file << "};\n\n";

            file << "XPDATA xpdata_" << mesh << "[] = {\n   {\n";
            file << "       point_" << mesh << ", sizeof(point_" << mesh << ")/sizeof(POINT),\n";
            file << "       polygon_" << mesh << ", sizeof(polygon_" << mesh << ")/sizeof(POLYGON),\n";
            file << "       attribute_" << mesh << ",\n       normal_" << mesh << "\n  }\n";
            file << "};\n\n";


        }
    }
#if 0
    unsigned int cntPnt = 0;
    unsigned int cntPlt = 0;

    for (unsigned int mesh=0; mesh<model->TOTAL_MESH; mesh++)
    {
        cntPnt += model->pol[mesh].nbPoint;
        cntPlt += model->pol[mesh].nbPolygon;
    }
    file << "//TOTAL POINTS : " << cntPnt << "\n";
    file << "//TOTAL POLYGONS : " << cntPlt << "\n";


    file << "#ifndef _ANORM_h\n#define _ANORM_h\n";
    file << "\nVECTOR ANORMS[]={\n";
    for (int i=0; i<model->pol[0].nbPoint; i++)
    {
        float buf[3];
        buf[X]=toFLOAT(model->pol[0].pntbl[i][X]);
        buf[Y]=toFLOAT(model->pol[0].pntbl[i][Y]);
        buf[Z]=toFLOAT(model->pol[0].pntbl[i][Z]);
        float dist=sqrtf((buf[X]*buf[X])+(buf[Y]*buf[Y])+(buf[Z]*buf[Z]));
        if (dist != 0)
        {
            buf[X]= (buf[X]/dist);
            buf[Y]= (buf[Y]/dist);
            buf[Z]= (buf[Z]/dist);
        }
        file << "POStoFIXED(" << buf[X] << ", " << buf[Y] << ", " << buf[Z] << "),\n";
    }
    file << "};";
#endif // 0
    file.close();
    return true;
}


int writeShadows(string filename, animated_model_t * aModel)
{
    return 0;
    #if 0
    return 0;
    ofstream file(filename, ios::out);
    if (!file.is_open()) {cout << "ERROR...\n"; return false;}

  /*  uint8_t shadow[32*32];
    memset(&shadow[0], 0, sizeof(shadow));
    for (int j=0; j<aModel->model.nbPoint; j++){
            shadow[aMo]
    }*/
    for (int i=0; i<aModel->nbFrames; i++){
        uint8_t shadow[32*32];
        memset(&shadow[0], 0, sizeof(shadow));

        for (int ii=0; ii<aModel->keyFrames[i]; ii++){
            key_frame_t * kf = &aModel->keyFrames[i];

        }
    }
    return true;
    #else
           glClearColor(0.4f, 0.4f, 0.5f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);
        glMatrixMode(GL_MODELVIEW);
        glDisable(GL_CULL_FACE);
        glColor4f(1.0f,1.0f,1.0f,1.0f);

        glPushMatrix();
        glMatrixMode(GL_MODELVIEW);
        gluLookAt(0.0, 0.0, -0.1, 0.0, 0.0, 0.0, 0.0, -1.0, 0.0);

extern player_t PLAYER[];
            glRotatef(PLAYER[0].ROTATION[X], 1.0f, 0.0f, 0.0f);
            glRotatef(PLAYER[0].ROTATION[Y], 0.0f, 1.0f, 0.0f);
            glTranslatef(-PLAYER[0].POSITION[X], -PLAYER[0].POSITION[Y], -PLAYER[0].POSITION[Z]);
            glScalef(aModel->scale[X],aModel->scale[Y], aModel->scale[Z]);


            glEnable(GL_BLEND);
            glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);
            glDisable(GL_POLYGON_STIPPLE);
           // glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, 0x0105);
            //glBlendFunc(GL_FUNC_ADD, GL_ONE_MINUS_SRC_ALPHA);

            /*if (aModel->nbFrames>0){
                ztUpdateAnimation(&PLAYER[0].ANIMCTRL, aModel);
            }*/

            const float cOffset = 0.5;
            extern unsigned int texId[];
            for (unsigned int m=0; m<aModel->nbModels; m++)
            {
                model_t * curModel = &aModel->model[m];
                vertex_t * curVert;
                for (unsigned int i=0; i<curModel->nbPolygon; i++)
                {

                    polygon_t * pol = &curModel->pltbl[i];
                    glBindTexture(GL_TEXTURE_2D, texId[pol->texture]);
                    if (aModel->texture[pol->texture].attributes & TEX_NO_GOURAUD) glColor4f(1,1,1,1);
                    if (pol->SGL_ATTR.flag & Dual_Plane) glDisable(GL_CULL_FACE);
                    else glEnable(GL_CULL_FACE);

                   // float transValue = 1.0f;
                    int dir = (pol->SGL_ATTR.dir>>4)&3;



        int newUseUV=0;
        extern float SaturnUV[];

                    glBegin(GL_QUADS);
                    {

                        for (int32_t ii=3; ii>=0; --ii) {
                            if (newUseUV)
                                glTexCoord2f(pol->vertUV[ii].U, pol->vertUV[ii].V);
                            else
                                glTexCoord2f(SaturnUV[ii*2+(dir*8)], (SaturnUV[(ii*2) + 1 + (dir*8)]));
                            curVert = &curModel->pntbl[pol->vertIdx[ii]];
                            {
                                {
                                    glColor4f(1,1,1,1.0f);
                                }
                            }
                            glVertex3f(curVert->point[X], curVert->point[Y], curVert->point[Z]);
                        }

                    }
                    glEnd();
                }
            }

            glPopMatrix();
glPopMatrix();
                    std::vector<unsigned char> png;
                    for (int h=0; h<640; h+=16){
                        for (int w=192; w<1024-192; w+=16){
                            unsigned char data[4];
                            glReadPixels(w, 639-h, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, data);
                            for (int i=0; i<4; i++){
                                png.push_back(data[i]);
                            }
                        }

                    }




                unsigned error = lodepng::encode("SHADOW.PNG" , png, 640/16, 640/16);


            glClear(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);
    #endif
}
