#include "../COMMON.H"

/***
In case you are wondering, I reused code from my early FPS tests, so you can see stuff like "is_firing" which is obviously not for the model converter...
***/

extern int DisplayTEST;
extern int ZT_FRAMERATE;

#define KB_A 65
#define KB_D 68
#define KB_W 87
#define KB_S 83
#define KB_Z 90
#define KB_Q 81
#define KB_E 69
#define KB_C 67
#define KB_ESC 126

#define AslMulFX(a,b) (a*b)

sKeyState m_keys[256], m_mouse[5];
sKeyState GetKey(int nKeyID){ return m_keys[nKeyID]; }


short   m_keyNewState[256]    = { 0 };
short   m_keyOldState[256]    = { 0 };
POINT   p                     = { 0 };
VECTOR  m_pos                 = { 0 };

void resetKeyPresses(player_t * player)
{
    if (player->PLAYER_ID >= 4) return;

    for (int i = 0; i < 256; i++)
    {
        m_keyNewState[i] = GetAsyncKeyState(i);
		m_keys[i].bPressed = false;	m_keys[i].bReleased = false;

		if (m_keyNewState[i] != m_keyOldState[i])
		{
            if (m_keyNewState[i] & 0x8000)
			{
                m_keys[i].bPressed = !m_keys[i].bHeld;
				m_keys[i].bHeld = true;
            }
			else
			{
                m_keys[i].bReleased = true;
				m_keys[i].bHeld = false;
            }
        }
        m_keyOldState[i] = m_keyNewState[i];
    }

}


#define SPEED_INCREASE (0.5f*ZT_FRAMERATE)
#define FRICTION        (0.25f)
#define SPEED_VALUE     (3.0f)
#define TURN_INCREASE   (0.001375f * ZT_FRAMERATE)
#define LOOK_INCREASE   (0.001f * ZT_FRAMERATE)
/**Movement**/
void move_front(player_t * currentPlayer){   if ((currentPlayer->MOVEMENT_SPEED+=SPEED_INCREASE)>SPEED_VALUE)       currentPlayer->MOVEMENT_SPEED=SPEED_VALUE;}
void move_back(player_t * currentPlayer){    if ((currentPlayer->MOVEMENT_SPEED-=SPEED_INCREASE)<-SPEED_VALUE)      currentPlayer->MOVEMENT_SPEED=-SPEED_VALUE;}
void move_left(player_t * currentPlayer){    if ((currentPlayer->LATERAL_SPEED -= SPEED_INCREASE) < -SPEED_VALUE)   currentPlayer->LATERAL_SPEED = -SPEED_VALUE;}
void move_right(player_t * currentPlayer){   if ((currentPlayer->LATERAL_SPEED += SPEED_INCREASE) > SPEED_VALUE)    currentPlayer->LATERAL_SPEED = SPEED_VALUE;}

void move_friction(player_t * currentPlayer)
{
    if (currentPlayer->MOVEMENT_SPEED > SPEED_INCREASE)          currentPlayer->MOVEMENT_SPEED-=FRICTION*ZT_FRAMERATE;
    else if (currentPlayer->MOVEMENT_SPEED < -SPEED_INCREASE)   currentPlayer->MOVEMENT_SPEED+=FRICTION*ZT_FRAMERATE;
    else currentPlayer->MOVEMENT_SPEED = 0;
}


/**For the Lookup/down values : DEGtoANG(45) = 45/360 * 65536.0**/
void look_up(player_t * currentPlayer)   {    currentPlayer->ROTATION[Z]+=LOOK_INCREASE;    if (currentPlayer->ROTATION[Z] > 8192)  currentPlayer->ROTATION[Z] = 8192;}
void look_down(player_t * currentPlayer) {    currentPlayer->ROTATION[Z] -= LOOK_INCREASE;    if (currentPlayer->ROTATION[Z] < -8192) currentPlayer->ROTATION[Z] = -8192;}

/**Turn left/right - SATURN ONLY, DIGITAL PAD ONLY**/
void turn_left(player_t * currentPlayer){    currentPlayer->ROTATION[Z] -= TURN_INCREASE;}
void turn_right(player_t * currentPlayer){    currentPlayer->ROTATION[Z] += TURN_INCREASE;}


void resetPlayer(player_t * player)
{
    player->POSITION[X]=player->POSITION[Y]=player->POSITION[Z]=0;
    player->IS_FIRING=0;
    player->LATERAL_SPEED=0;
    player->MOVEMENT_SPEED=0;
    player->ROTATION[X]=player->ROTATION[Y]=player->ROTATION[Z]=0;

    player->POSITION[Z]=50;
    player->ROTATION[Z]=-180.0;
}



void debugKeys(player_t * player)
{
    if (m_keys['X'].bPressed)
    {if (++DisplayTEST > 3) DisplayTEST=0;}

    if (m_keys[32].bPressed)
        resetPlayer(player);

    /*if (m_keys['F'].bPressed)
    {
        ZT_FRAMERATE++;
        if (ZT_FRAMERATE>4) ZT_FRAMERATE=1;
    }*/

    extern int enableInterpolation;
    if (m_keys['I'].bPressed)
        enableInterpolation ^= 1;
}

POINT oldPoint;
void mouse_controls(player_t * player, animated_model_t * model)
{
    ShowCursor(true);
  //  GetWindowPl
    if (GetKeyState(VK_RBUTTON) < 0) {
         if (GetCursorPos(&p))
        {
            p.x = p.x - (1024/2+64);
            p.y = p.y - (640/2+64);
            player->ROTATION[Z] -= p.x * 0.0625f;
            player->ROTATION[X] += p.y * 0.0625f;

        }

    }
    //SetPhysicalCursorPos(320, 240);
    SetCursorPos(1024/2+64,640/2+64);

    if (GetKeyState(VK_LBUTTON) < 0) {
            glPushMatrix();

            glRotatef(player->ROTATION[X], 1.0f, 0.0f, 0.0f);
            glRotatef(player->ROTATION[Y], 0.0f, 1.0f, 0.0f);
            glTranslatef(-player->POSITION[X], -player->POSITION[Y], -player->POSITION[Z]);
            glScalef(model->scale[X],model->scale[Y], model->scale[Z]);
            glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

            extern int activeModel;
    //extern unsigned int texId[];
    extern int activeFace;
    extern unsigned int specialTextureId[];

            glDisable(GL_CULL_FACE);
            glDisable(GL_POLYGON_STIPPLE);
            //glDisable(GL_TEXTURE);

        for (int j=0; j<(int)model->nbModels; j++){
            model_t * curModel = &model->model[j];
            vertex_t * curVert;
            glColor4f(1,1,1,1);
            glBindTexture(GL_TEXTURE_2D, specialTextureId[j]);
            for (int i=0; i<(int)model->model[j].nbPolygon; i++){
           // glColor4f((i&255)/255.0,((i>>8)&255)/255.0,((i>>16)&255)/255.0,1);
            //glColor4ub((i&255),((i>>8)&255),((i>>16)&255),255);

                glBegin(GL_QUADS);
                {
                    for (int32_t ii=3; ii>=0; --ii) {
                        curVert = &curModel->pntbl[curModel->pltbl[i].vertIdx[ii]];
                        glTexCoord2f((i&255)/255.0f, (((i>>8)&255))/ 255.0);
                        glVertex3f(curVert->point[X], curVert->point[Y], curVert->point[Z]);
                    }
                }
                glEnd();
            }
        }

        glFlush();
        glFinish();

        unsigned char data[4];
        glReadPixels(1024/2, 640/2, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, data);
       // cout << ((*(int32_t*)&data[0])&255) << " " << (((*(int32_t*)&data[0])>>8)&255) << " " << (((*(int32_t*)&data[0])>>16)&255) << " " << (((*(int32_t*)&data[0])>>24)&255) << "\n";

        activeModel = ((*(int32_t*)&data)>>16)&255;
        if (activeModel >=0 && activeModel < (int)model->nbModels) {
            activeFace=((*(int32_t*)&data)&255) | ((((*(int32_t*)&data)>>8)&255)<<8);
            if (activeFace >= (int)model->model[activeModel].nbPolygon || activeFace<0) activeFace=-1;
        } else {
            activeModel=0;
            activeFace=-1;
        }

    glPopMatrix();
    glClear(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);
    }
}

void rotatePol(polygon_t * pol){
    unsigned int idxArray[4];
    uv_t         vertUV[4];

    for (int i=0; i<4; i++){
        idxArray[i]=pol->vertIdx[i];
        vertUV[i].U = pol->vertUV[i].U;
        vertUV[i].V = pol->vertUV[i].V;
    }
    for (int i=0; i<4; i++){
        int idx = (i+1)&3;
        pol->vertIdx[i]=idxArray[idx];
        pol->vertUV[i].U=vertUV[idx].U;
        pol->vertUV[i].V=vertUV[idx].V;
    }
}

void textureFlip(polygon_t * pol){
    pol->SGL_ATTR.dir=(pol->SGL_ATTR.dir&0xFFCF)|
        ((pol->SGL_ATTR.dir+(1<<4))&0x0030);
}

int keyboard_controls(player_t * player, animated_model_t * model)
{
    //glDisable(GL_TEXTURE);

    /*for (int i=0; i<model->model[0]->nbPolygon; i++){
        render
    }*/
    if (m_keys[27].bHeld || m_keys['O'].bHeld /*|| m_keys['Q'].bHeld*/) return -1;
    extern int activeFace;
    extern int activeModel;

    if (m_keys['P'].bPressed){
        extern int playAnimation;
        playAnimation^=1;
    }
    if (m_keys['L'].bPressed){
        extern int activeShading;
        activeShading^=1;
    }

    /*if (m_keys['U'].bPressed) {
        if (++activeModel >= model->nbModels) activeModel=0;
        activeFace=-1;
    }*/



    if (m_keys[9].bPressed){
        if (++activeFace >= (int)model->model[activeModel].nbPolygon) {
            activeFace=0;
        }
    } else if (m_keys[VK_SHIFT].bPressed) {
        if (--activeFace<0) {
            activeFace=model->model[activeModel].nbPolygon-1;
        }
    }


    if (m_keys['C'].bPressed && (((uint32_t)activeFace)<model->model[activeModel].nbPolygon)){
        model->model[activeModel].pltbl[activeFace].SGL_ATTR.flag^=Dual_Plane;
    }

    if (m_keys['F'].bPressed && (((uint32_t)activeFace)<model->model[activeModel].nbPolygon)){
        textureFlip(&model->model[activeModel].pltbl[activeFace]);
    }

    if (m_keys['G'].bPressed && (((uint32_t)activeFace)<model->model[activeModel].nbPolygon)){
        model->model[activeModel].pltbl[activeFace].SGL_ATTR.dir ^= (1<<8);/*(model->model[activeModel].pltbl[activeFace].SGL_ATTR.dir&0xFFCF)|
        ((model->model[activeModel].pltbl[activeFace].SGL_ATTR.dir+(1<<4))&0x0030);*/
    }

    if (m_keys['R'].bPressed && (((uint32_t)activeFace)<model->model[activeModel].nbPolygon)){
        rotatePol(&model->model[activeModel].pltbl[activeFace]);
    }

    if (m_keys['M'].bPressed && (((uint32_t)activeFace)<model->model[activeModel].nbPolygon)){
        model->model[activeModel].pltbl[activeFace].SGL_ATTR.atrb ^= MESHon;
    }

    if (m_keys['H'].bPressed && (((uint32_t)activeFace)<model->model[activeModel].nbPolygon)){
        model->model[activeModel].pltbl[activeFace].SGL_ATTR.atrb ^= CL_Gouraud;
    }
    if (m_keys['N'].bPressed && (((uint32_t)activeFace)<model->model[activeModel].nbPolygon)){
        model->model[activeModel].pltbl[activeFace].SGL_ATTR.sorting = (model->model[activeModel].pltbl[activeFace].SGL_ATTR.sorting&0xFFFC) |
        ((model->model[activeModel].pltbl[activeFace].SGL_ATTR.sorting+1)&3);
    }

    /**REMOVED FOR DEBUGGING**/
    /*if ((player->STATUS & CAN_JUMP)&&(m_keys[' '].bPressed || (GetKeyState(VK_RBUTTON) < 0)))
    {
        player->SPEED[Y] = -20.0f;
        //player->STATUS &= ~CAN_JUMP;
    }*/

    if (m_keys['D'].bHeld)
        move_right(player);
    else if (m_keys['A'].bHeld)
        move_left(player);
    else if (player->LATERAL_SPEED > SPEED_INCREASE) player->LATERAL_SPEED-=SPEED_INCREASE;
    else if (player->LATERAL_SPEED < -SPEED_INCREASE) player->LATERAL_SPEED+=SPEED_INCREASE;
    else player->LATERAL_SPEED=0;

    if (fabs(player->LATERAL_SPEED)< FRICTION) player->LATERAL_SPEED=0;

    if (m_keys['W'].bHeld)
    {
        move_front(player);
    }
    else if (m_keys['S'].bHeld)
    {
        move_back(player);
    }
    else move_friction(player);

    /**For debugging, no collision**/
#if 1

    if (m_keys['Q'].bHeld)
        player->SPEED[Y]-=1.0f*ZT_FRAMERATE;
    else if (m_keys['Z'].bHeld)
        player->SPEED[Y]+=1.0f*ZT_FRAMERATE;
    else player->SPEED[Y]*=0.5f;
#endif

    if (fabs(player->SPEED[Y]) < 1.0f/32.0f) player->SPEED[Y]=0;

    debugKeys(player);

    return 0;
}


/**Update player's data**/
void update(player_t * player)
{
    player->ROTATION[Y] = player->ROTATION[Z];

    player->SPEED[Z] = AslMulFX(std::cos(player->ROTATION[Y]*conv), (player->MOVEMENT_SPEED)) +
        AslMulFX(std::sin(player->ROTATION[Y]*conv), (player->LATERAL_SPEED));

    player->SPEED[X] = -AslMulFX(std::sin(player->ROTATION[Y]*conv), (player->MOVEMENT_SPEED)) +
        AslMulFX(std::cos(player->ROTATION[Y]*conv), (player->LATERAL_SPEED));

    if (player->SPEED[Y] > 15.0f) player->SPEED[Y] = 15.0f;
    player->NEXT_POSITION[X] = player->POSITION[X] + player->SPEED[X] * ZT_FRAMERATE;
    player->NEXT_POSITION[Y] = player->POSITION[Y] + player->SPEED[Y] * ZT_FRAMERATE;
    player->NEXT_POSITION[Z] = player->POSITION[Z] + player->SPEED[Z] * ZT_FRAMERATE;

    //Disabled for debug
    //player->STATUS &= ~CAN_JUMP;
}
/**Temporary functions...**/
int myControls(player_t * player, animated_model_t*model)
{


   /* if (is_input_available(currentPlayer->PLAYER_ID) == false) return;

    if(Smpc_Peripheral[currentPlayer->PLAYER_ID].id == 0x16)
        {analog_control(currentPlayer);}
	else
        {digital_control(currentPlayer);}

    update(currentPlayer);*/


   // player->SPEED[Y] += 3.0f * ZT_FRAMERATE;

    mouse_controls(player, model);
    resetKeyPresses(player);
    if (keyboard_controls(player, model)==-1) return -1;

    update(player);
       //     cout << "Player Position : " << (int)player->POSITION.x << ", " << (int)player->POSITION.y << ", " << (int)player->POSITION.z << "\n";
    return 0;
}
